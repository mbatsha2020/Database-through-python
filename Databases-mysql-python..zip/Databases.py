from tkinter import *
import pymysql
home= 'urHomeWindow'
from PIL import Image
root = tk.Tk()
w = tk.Label(root, text="Hello Tkinter!")
w.pack()


def login():
    global username
    try:
        connection = pymysql.connect(host='localhost', user='lifechoices', database='lifechoicesonline')
    except:
        print("You are no connected to server(localhost)")
    else:
        print('Connected Successfully')
        print("Enter your username and password")
        username = user.get()
        password = pass.get()
        cur = connection.cursor()
        quuery = "Select username, password from users"
        cur.execute(query)
        for (username, password) in cur:
            if username==username and password==password:
                login = True
                break
            else:
                login = False
        userID = (username.split)
        if login == True:
            print("Logged in successfully as",userID)
            newWindow()
        elif login == False:
            print("username or password is wrong")
            cur.close()
            connection.close()

def newWindow():
    global username, home
    root.withdraw()        #CLOSE THE LOGIN WINDOW
         #open new window
    home.title('Main Window')
    home.geometry('500x600')
    home.config(bg='azure')
    something = Label(home, text="You are logged in successfully".format(username), fg='green', bg='azure')
    something.place(x=120, y=120)
    logout = Button (home = text='logout', image=lo,fg='white, bg='red', activebackground='blue', width=100, height=20, command=logout, compund=LEFT)
    logout.place(x=400,x=20)
    #home.mainloop()
def logout():
    global home
    home.withdraw()
    root.deiconify()
    print("Logged out successfully")

#root Window==================>
root = tk()
root.config(bg='green')
root.title('Login Window')
root.geometry('530x430')
root.resizeable(0,0)
image = Image(file = lco.png)
root.wm_iconbitmap("icon.ico")
#========================>
bgLabel = Label(root, image=image)
bgLabel.place(x=0, y=0)
nametag = Label(root, text="Lifechoices Login Portal", font=('arial',10,'bold',), fg='green').place(x=120,y=335)
#========================>
site = Label(root, text="Login to Lifechoices", font=('arial',15,'bold','underline'),fg='blue3')
site.place(x=220,y=120)

#Username
username_entry = Label(root, text="Username: ", font=('arial',10,'bold'), fg='blue').place(x=120,y=180)
user = entry(root,width=30,font=('calibri',12))
user.place(x=200,y=180)
#Password
password_entry = Label(root, text="Password: ", font=('arial',10,'bold'), fg='blue').place(x=120,y=230)
password.place(x= 250, y=280)
#Submit
submit =Button(root,text='Login', image=li, fg='white', bg='green', width=100, height=20, command=login,)
submit.place(x=250, y=280)

#close loop
root.mainloop
